import './App.css'
import PokemonList from './components/PokemonList'

function App() {

  return (
    <>
      <PokemonList />
    </>
  )
}

export default App
